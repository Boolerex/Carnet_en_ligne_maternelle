-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3308
-- Généré le :  mer. 26 fév. 2020 à 16:03
-- Version du serveur :  5.7.28
-- Version de PHP :  7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `ecole2020`
--

-- --------------------------------------------------------

--
-- Structure de la table `année_scolaire`
--

DROP TABLE IF EXISTS `année_scolaire`;
CREATE TABLE IF NOT EXISTS `année_scolaire` (
  `année_scolaire` varchar(20) NOT NULL,
  `début` varchar(10) NOT NULL,
  `fin` varchar(10) NOT NULL,
  PRIMARY KEY (`année_scolaire`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `année_scolaire`
--

INSERT INTO `année_scolaire` (`année_scolaire`, `début`, `fin`) VALUES
('2019/2020', '20/09/2019', '01/05/2020'),
('2020/2021', '20/09/2020', '01/05/2021');

-- --------------------------------------------------------

--
-- Structure de la table `classe`
--

DROP TABLE IF EXISTS `classe`;
CREATE TABLE IF NOT EXISTS `classe` (
  `id_classe` varchar(20) NOT NULL,
  `nom_classe` text NOT NULL,
  `description` varchar(20) NOT NULL,
  `salle` varchar(20) NOT NULL,
  `année_scolaire` varchar(20) NOT NULL,
  PRIMARY KEY (`id_classe`),
  KEY `année_scolaire` (`année_scolaire`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `classe`
--

INSERT INTO `classe` (`id_classe`, `nom_classe`, `description`, `salle`, `année_scolaire`) VALUES
('CM1', 'classe maternelle un', 'cool', 'c\'est quoi ca', '2019/2020'),
('CM2', 'classe maternelle deux', 'sympa', 'je ne sais tjrs pas ', '2019/2020');

-- --------------------------------------------------------

--
-- Structure de la table `compétence`
--

DROP TABLE IF EXISTS `compétence`;
CREATE TABLE IF NOT EXISTS `compétence` (
  `id_com` varchar(20) NOT NULL,
  `champ1` varchar(13) NOT NULL,
  `champ2` varchar(13) NOT NULL,
  `champ3` varchar(13) NOT NULL,
  `nom_compétence` text NOT NULL,
  `intitulé_section` varchar(20) NOT NULL,
  PRIMARY KEY (`id_com`),
  KEY `id_section` (`intitulé_section`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `compétence`
--

INSERT INTO `compétence` (`id_com`, `champ1`, `champ2`, `champ3`, `nom_compétence`, `intitulé_section`) VALUES
('COM1', 'un', 'deux', 'trois', 'mathématiques', 'CM2020'),
('COM2', 'one', 'two', 'three', 'viva ALGERIE', 'CM2021');

-- --------------------------------------------------------

--
-- Structure de la table `direction_classe`
--

DROP TABLE IF EXISTS `direction_classe`;
CREATE TABLE IF NOT EXISTS `direction_classe` (
  `id_direction_classe` varchar(20) NOT NULL,
  `qualité` tinyint(1) NOT NULL,
  `id_personnel` varchar(20) NOT NULL,
  `date_début` date NOT NULL,
  `date_fin` date NOT NULL,
  `id_classe` varchar(20) NOT NULL,
  PRIMARY KEY (`id_direction_classe`),
  KEY `id_classe` (`id_classe`),
  KEY `id_personnel` (`id_personnel`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `direction_classe`
--

INSERT INTO `direction_classe` (`id_direction_classe`, `qualité`, `id_personnel`, `date_début`, `date_fin`, `id_classe`) VALUES
('DIR1', 0, 'per1', '2019-01-01', '2020-01-01', 'CM1'),
('DIR2', 0, 'per2', '2020-01-02', '2021-01-02', 'CM2');

-- --------------------------------------------------------

--
-- Structure de la table `direction_ecole`
--

DROP TABLE IF EXISTS `direction_ecole`;
CREATE TABLE IF NOT EXISTS `direction_ecole` (
  `id_direction_école` varchar(20) NOT NULL,
  `qualité` tinyint(1) NOT NULL,
  `id_personnel` varchar(20) NOT NULL,
  `date_début` date NOT NULL,
  `date_fin` date NOT NULL,
  `id_année_scolaire` varchar(20) NOT NULL,
  PRIMARY KEY (`id_direction_école`),
  KEY `id_personnel` (`id_personnel`,`id_année_scolaire`),
  KEY `id_année_scolaire` (`id_année_scolaire`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `direction_ecole`
--

INSERT INTO `direction_ecole` (`id_direction_école`, `qualité`, `id_personnel`, `date_début`, `date_fin`, `id_année_scolaire`) VALUES
('DE1', 0, 'per1', '2019-09-20', '2020-09-20', '2019/2020'),
('DE2', 0, 'per2', '2010-09-01', '2021-09-01', '2020/2021');

-- --------------------------------------------------------

--
-- Structure de la table `inscription`
--

DROP TABLE IF EXISTS `inscription`;
CREATE TABLE IF NOT EXISTS `inscription` (
  `id_inscription` varchar(20) NOT NULL,
  `id_élève` varchar(20) NOT NULL,
  `id_classe` varchar(20) NOT NULL,
  `intitulé_section` varchar(20) NOT NULL,
  `validité` varchar(13) NOT NULL,
  `date_opération` date NOT NULL,
  PRIMARY KEY (`id_inscription`),
  KEY `id_élève` (`id_élève`,`id_classe`,`intitulé_section`),
  KEY `intitulé_section` (`intitulé_section`),
  KEY `id_classe` (`id_classe`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `inscription`
--

INSERT INTO `inscription` (`id_inscription`, `id_élève`, `id_classe`, `intitulé_section`, `validité`, `date_opération`) VALUES
('IN1', '20202020', 'CM1', 'CM2020', 'a savoir', '2020-01-01'),
('IN2', '20202021', 'CM2', 'CM2021', 'a voir', '2020-01-29');

-- --------------------------------------------------------

--
-- Structure de la table `parent`
--

DROP TABLE IF EXISTS `parent`;
CREATE TABLE IF NOT EXISTS `parent` (
  `id_parent` varchar(20) NOT NULL,
  `nom_parent` text NOT NULL,
  `prénom_parent` text NOT NULL,
  `email_parent` varchar(50) NOT NULL,
  `adresse_parent` varchar(50) NOT NULL,
  PRIMARY KEY (`id_parent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `parent`
--

INSERT INTO `parent` (`id_parent`, `nom_parent`, `prénom_parent`, `email_parent`, `adresse_parent`) VALUES
('P1', 'merzouk papa', 'amine papa', 'amine.merzouk@gmail.com', '1 rue paradis , 75000 paris'),
('P2', 'henane papa', 'houssem papa', 'henane.houssem@gmail.com', '2 rue rose, 91000 evry');

-- --------------------------------------------------------

--
-- Structure de la table `personnel`
--

DROP TABLE IF EXISTS `personnel`;
CREATE TABLE IF NOT EXISTS `personnel` (
  `id_personnel` varchar(20) NOT NULL,
  `nom_personnel` text NOT NULL,
  `prénom_personnel` text NOT NULL,
  `email_personnel` varchar(20) NOT NULL,
  `téléphone_personnel` int(11) NOT NULL,
  PRIMARY KEY (`id_personnel`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `personnel`
--

INSERT INTO `personnel` (`id_personnel`, `nom_personnel`, `prénom_personnel`, `email_personnel`, `téléphone_personnel`) VALUES
('per1', 'seguy', 'nico', 'nico.seguy@gmail.com', 0),
('per2', 'sadi', 'yas', 'yas.sadi@gmail.com', 0);

-- --------------------------------------------------------

--
-- Structure de la table `section`
--

DROP TABLE IF EXISTS `section`;
CREATE TABLE IF NOT EXISTS `section` (
  `intitulé_section` varchar(20) NOT NULL,
  `description_section` varchar(20) NOT NULL,
  PRIMARY KEY (`intitulé_section`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `section`
--

INSERT INTO `section` (`intitulé_section`, `description_section`) VALUES
('CM2020', 'sect 1'),
('CM2021', 'sect 2');

-- --------------------------------------------------------

--
-- Structure de la table `valider`
--

DROP TABLE IF EXISTS `valider`;
CREATE TABLE IF NOT EXISTS `valider` (
  `Id_eleve` varchar(20) NOT NULL,
  `id_com` varchar(20) NOT NULL,
  `id_personnel` varchar(20) NOT NULL,
  `date_valider` date NOT NULL,
  `photo` blob NOT NULL,
  PRIMARY KEY (`Id_eleve`,`id_com`,`id_personnel`),
  KEY `id_com` (`id_com`),
  KEY `id_personnel` (`id_personnel`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `valider`
--

INSERT INTO `valider` (`Id_eleve`, `id_com`, `id_personnel`, `date_valider`, `photo`) VALUES
('20202020', 'COM1', 'per1', '2020-02-13', '');

-- --------------------------------------------------------

--
-- Structure de la table `élève`
--

DROP TABLE IF EXISTS `élève`;
CREATE TABLE IF NOT EXISTS `élève` (
  `id_élève` varchar(20) NOT NULL,
  `nom_élève` text NOT NULL,
  `prénom-élève` text NOT NULL,
  `date_naissance` date NOT NULL,
  PRIMARY KEY (`id_élève`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `élève`
--

INSERT INTO `élève` (`id_élève`, `nom_élève`, `prénom-élève`, `date_naissance`) VALUES
('20202020', 'merzouk ', 'amine', '2016-01-01'),
('20202021', 'henane ', 'houssem', '2016-02-02');

-- --------------------------------------------------------

--
-- Structure de la table `élève_avoir_parent`
--

DROP TABLE IF EXISTS `élève_avoir_parent`;
CREATE TABLE IF NOT EXISTS `élève_avoir_parent` (
  `id_parent` varchar(20) NOT NULL,
  `id_élève` varchar(20) NOT NULL,
  `appeler priorité` text NOT NULL,
  PRIMARY KEY (`id_parent`,`id_élève`),
  KEY `élève-parent` (`id_élève`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `élève_avoir_parent`
--

INSERT INTO `élève_avoir_parent` (`id_parent`, `id_élève`, `appeler priorité`) VALUES
('P1', '20202020', 'la mama'),
('P2', '20202021', 'le papa');

-- --------------------------------------------------------

--
-- Structure de la table `être_en_poste`
--

DROP TABLE IF EXISTS `être_en_poste`;
CREATE TABLE IF NOT EXISTS `être_en_poste` (
  `id_personnel` varchar(20) NOT NULL,
  `année_scolaire` varchar(20) NOT NULL,
  `qualité` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_personnel`,`année_scolaire`),
  KEY `année-poste` (`année_scolaire`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `être_en_poste`
--

INSERT INTO `être_en_poste` (`id_personnel`, `année_scolaire`, `qualité`) VALUES
('per1', '2019/2020', 1),
('per2', '2020/2021', 2);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `classe`
--
ALTER TABLE `classe`
  ADD CONSTRAINT `classe_ibfk_1` FOREIGN KEY (`année_scolaire`) REFERENCES `année_scolaire` (`année_scolaire`);

--
-- Contraintes pour la table `compétence`
--
ALTER TABLE `compétence`
  ADD CONSTRAINT `compétence_ibfk_1` FOREIGN KEY (`intitulé_section`) REFERENCES `section` (`intitulé_section`);

--
-- Contraintes pour la table `direction_classe`
--
ALTER TABLE `direction_classe`
  ADD CONSTRAINT `direction_classe_ibfk_1` FOREIGN KEY (`id_personnel`) REFERENCES `personnel` (`id_personnel`),
  ADD CONSTRAINT `direction_classe_ibfk_2` FOREIGN KEY (`id_classe`) REFERENCES `classe` (`id_classe`);

--
-- Contraintes pour la table `direction_ecole`
--
ALTER TABLE `direction_ecole`
  ADD CONSTRAINT `direction_ecole_ibfk_1` FOREIGN KEY (`id_personnel`) REFERENCES `personnel` (`id_personnel`),
  ADD CONSTRAINT `direction_ecole_ibfk_2` FOREIGN KEY (`id_année_scolaire`) REFERENCES `année_scolaire` (`année_scolaire`);

--
-- Contraintes pour la table `inscription`
--
ALTER TABLE `inscription`
  ADD CONSTRAINT `inscription_ibfk_2` FOREIGN KEY (`id_élève`) REFERENCES `élève` (`id_élève`),
  ADD CONSTRAINT `inscription_ibfk_3` FOREIGN KEY (`id_classe`) REFERENCES `classe` (`id_classe`),
  ADD CONSTRAINT `inscription_ibfk_4` FOREIGN KEY (`intitulé_section`) REFERENCES `section` (`intitulé_section`);

--
-- Contraintes pour la table `valider`
--
ALTER TABLE `valider`
  ADD CONSTRAINT `valider_ibfk_1` FOREIGN KEY (`Id_eleve`) REFERENCES `élève` (`id_élève`),
  ADD CONSTRAINT `valider_ibfk_2` FOREIGN KEY (`id_com`) REFERENCES `compétence` (`id_com`),
  ADD CONSTRAINT `valider_ibfk_3` FOREIGN KEY (`id_personnel`) REFERENCES `personnel` (`id_personnel`);

--
-- Contraintes pour la table `élève_avoir_parent`
--
ALTER TABLE `élève_avoir_parent`
  ADD CONSTRAINT `élève-parent` FOREIGN KEY (`id_élève`) REFERENCES `élève` (`id_élève`),
  ADD CONSTRAINT `élève_avoir_parent_ibfk_1` FOREIGN KEY (`id_parent`) REFERENCES `parent` (`id_parent`);

--
-- Contraintes pour la table `être_en_poste`
--
ALTER TABLE `être_en_poste`
  ADD CONSTRAINT `année-poste` FOREIGN KEY (`année_scolaire`) REFERENCES `année_scolaire` (`année_scolaire`),
  ADD CONSTRAINT `être_en_poste_ibfk_1` FOREIGN KEY (`id_personnel`) REFERENCES `personnel` (`id_personnel`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
